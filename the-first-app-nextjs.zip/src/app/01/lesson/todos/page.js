"use client";

export default function Todos() {
    return (
        <main className="flex min-h-screen flex-col items-center justify-between p-24">
            <div>
                <h1>Todo List</h1>
            </div>

            <div>
                <p>
                    <button>Add Todos</button>
                </p>
            </div>
        </main>
    )
}
